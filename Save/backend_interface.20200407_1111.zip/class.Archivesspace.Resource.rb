=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
            AS = ArchivesSpace
            IT = instance type
            TC = top container
            SC = Sub-container
            _H = Hash
            _A = Array
            _I = Index(of Array)
            _O = Object
           _0R = Zero Relative

=end

class ASpace

    class Resource_Record_Buf < Record_Buf
    
        def initialize( p1_rep_O, p2_res_identifier )
            if ( p1_rep_O.class != Repository ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a Repository class object"
                raise
            end    
			super( p1_rep_O.aspace_O )
            @rep_O = p1_rep_O
            if ( p2_res_identifier == nil ) then
                @num = nil
                @uri = nil
            else
                if ( p2_res_identifier.integer? ) then
                    @num = p2_res_identifier
                    @uri = "#{@rep_O.uri}/resources/#{@num}"
                else
                    stringer = "#{@rep_O.uri}/archival_objects"
                    if ( stringer == p2_res_identifier[ 0 .. stringer.maxindex ]) then
                        @uri = p2_res_identifier
                        @num = p2_res_identifier.sub( /^.*\//, '' )
                        if (! @num.integer? ) then
                            Stderr.puts "#{Stderr.lineno}: =============================================="
                            Stderr.puts "Invalid param2: #{p2_res_identifier}"
                            raise
                        end
                    end
                end
            end
 
#           Stderr.puts "#{Stderr.lineno}: ============ In Resource :initialize @resource=#{@num}"
        end
        attr_reader :rep_O, :num, :uri, :record_H

        def create
            @record_H.merge!( jsonmodel_H ( K.archival_object ) )
            return self
        end
        
        def read( filter_record_B = true )
            @record_H = super( filter_record_B )
    #       Stderr.pp "@record_H", @record_H
            if ( @record_H.key?( K.resource ) and  @record_H[ K.resource ].key?( K.ref )) then
                if ( ! ( @record_H[ K.resource ][ K.ref ] == "#{@uri}" ) ) then
                    Stderr.puts "uri is not part of resource '#{@num}'"
                    Stderr.puts "resource => uri = '#{@uri}'"
                    Stderr.pp "@record_H:", @record_H
                    raise
                end
            end
            return self
        end
        
        def store( )
            Stderr.puts "Method not coded"
            raise
        end
    end    
end

