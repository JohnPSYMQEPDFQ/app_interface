=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative

=end

class ASpace

    class Repository
        def initialize( p1_aspace_O, p2_rep_num )
            if ( p1_aspace_O.class != ASpace ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a ASpace class object"
                raise
            end    
            if ( ! p1_aspace_O.session or p1_aspace_O.session == K.undefined ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "aspace_O.session undefined, do the ASpace#login method first."
                raise
            end
            @aspace_O = p1_aspace_O
            @num = p2_rep_num
            @uri = "/repositories/#{@num}"
#           Stderr.puts "#{Stderr.lineno}: ================ In Repository:initialize,@num=#{@num}"
        end
        attr_reader :aspace_O, :num, :uri
           
    end
    
    class Tree_Query
        def initialize( p1_rep_O )
            @rep_O = p1_rep_O
            @result = nil
        end
        attr_reader :result

        def get_resource_tree( res_num )
=begin
{"title"=>"Philip Ross Hastings, M.D. collection",
 "id"=>70,
 "node_type"=>'resource',
 "publish"=>true,
 "suppressed"=>false,
 "children"=> 
  [{"title"=>
     "Series 1: Promotional Materials: Institutions &amp; Sites, undated",
    "id"=>107016,
    "record_uri"=>"/repositories/2/archival_objects/107016",
    "publish"=>false,
    "suppressed"=>false,
    "node_type"=>"archival_object",
    "level"=>"series",
    "has_children"=>true,
    "children"=>
     [{"title"=>"A-B",
     ...
     ]
  ]
 "record_uri"=>"/repositories/2/resources/70",
 "finding_aid_filing_title"=>"Hastings (Dr. Philip Ross) Collection",
 "level"=>"collection",
 K.jsonmodel_type=>"resource_tree",
 "instance_types"=>[],
 "containers"=>[]}
=end
            uri = "#{@rep_O.uri}/resources/#{res_num}/tree"
            http_response_body = ASpace::Http_Calls.new( @rep_O.aspace_O ).http_get( uri, { } )
            if ( not ( http_response_body.has_key?( K.jsonmodel_type ) and http_response_body[ K.jsonmodel_type] == K.resource_tree )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Unable to find Resource Tree for res_num = #{res_num}"
                Stderr.puts "uri = #{uri}"
#               Stderr.pp "http_response_body", http_response_body
                raise
            end		
            @result = http_response_body
            return self
        end
        
        def get_res_tree_A_of_AO_record_buf_O( res_buf_O, child_A, child_ao_O_A = [ ] )
            child_A.each do | element |
                if ( element[ K.node_type ] == K.archival_object ) then
#                   Stderr.puts "pushed #{element[ K.level ]} #{element[ K.record_uri ]} "
                    child_ao_O_A << ASpace::AO_Record_Buf.new(res_buf_O, element[ K.record_uri ] ).read
                else
                    Stderr.puts "Dont' know what to do with element[ K.node_type ] == #{element[ K.node_type ]}"
                    raise
                end
                if ( element[ K.children ].is_a?( Array ) ) then
                    get_res_tree_A_of_AO_record_buf_O( res_buf_O, element[ K.children ], child_ao_O_A )
                end
            end
            return child_ao_O_A
        end
    end
end

