require 'json'
require 'class.Hash.extend.rb'
require 'class.Array.extend.rb'
require 'class.String.extend.rb'
j='{"root": [{'
j+='"archival_object":[ {"jsonmodel_type":"archival_object",
"external_ids":[],
"resource":{ "ref":"/repositories/2/resources/1"}}]'
j+=','
j+='"resource":[{"jsonmodel_type":"resource",
"external_ids":[],
"ead_location":"KLUC995"}]' 
j+='}]}'


def deep_keys_to_a_XXX(h)
            ar = [ ]
            h.each_pair do | k, v |
 #              puts "k = #{k}, v = #{v}, v.class = #{v.class}"
                if ( v.is_a?( Array )) then
                    a = v.map do | e |
                        if ( e.is_a?( Hash ) ) then
                            deep_keys_to_a( e )
                        else
                            e
                        end
                    end
                    ar << k
                    ar << a if ( a.maxindex >= 0 )
                elsif ( v.is_a?( Hash ) ) then
                    ar << k
                    ar << deep_keys_to_a( v ) 
                else
                    ar << k
                end
            end
            return ar
end

h = JSON.parse( j )
a = h.deep_keys_to_a
puts "OUT"
pp a
pp h
exit

def print_constants( a, jsonmodel_type )
    prev_e = jsonmodel_type
    a.each do | e |
        if (e.is_a?( Array )) then
            if ( e.maxindex >= 0 and e[0] == 'jsonmodel_type' ) then
                stringer = prev_e
            else
                stringer = jsonmodel_type
            end
            print_constants( e, stringer )
        else
            puts "    def K.#{e}; return '#{e}';end   # #{jsonmodel_type}"
            prev_e = e
        end
    end
end

print_constants( a, '')




