=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative

=end

class ASpace

    class Record_Buf < Buffer_Base
        def initialize( p1_aspace_O )
            super( )
            @cant_change_A << K.uri
            @http_calls_O = ASpace::Http_Calls.new( p1_aspace_O )
        end
        attr_reader :http_calls_O

        def jsonmodel_H( type )
            jsonmodel_H = {}
            h = {   K.jsonmodel_type => K.archival_object ,
                    K.resource => { 
                        K.ref => K.undefined 
                    } ,
                    K.parent => { 
                        K.ref => K.undefined    
                    } ,
                    K.title => K.undefined ,   #  "Southern Pacific" 
                    K.level => K.undefined ,
                    K.publish =>  true ,
                    K.dates => [] ,
                    K.notes => [] ,
                    K.instances=> { }                                
                } 
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            h = {   K.jsonmodel_type => K.date,
                    K.date_type => K.undefined,
                    K.label => K.undefined,
                    K.begin => K.undefined,
                    K.end => '',
                    K.certainty => '',
                    K.era => '',
                    K.calendar => '',
                    K.expression => ''
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            h = {   K.jsonmodel_type => K.instance,
                    K.is_representative => false,
                    K.instance_type => K.undefined ,
                    K.sub_container => {} 
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h   
                
            h = {
                    K.jsonmodel_type => K.note_multipart, 
                    K.ingest_problem => '', 
                    K.persistent_id => '', 
                    K.label => '', 
                    K.type => K.undefined, #(processinfo)
                    K.subnotes =>  [  ]			
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h   

            h =  {
                    K.jsonmodel_type => K.note_singlepart,
                    K.ingest_problem => '',
                    K.type => K.undefined,    #(physloc)
                    K.publish =>  true,
                    K.content => [ ],
                    K.label => '',
                    K.persistent_id => ''
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            h = {   K.jsonmodel_type => K.sub_container,
                    K.top_container => {
                        K.ref => K.undefined
                    },
                    K.type_2 => K.undefined,
                    K.indicator_2 => K.undefined,
                    K.type_3 => K.undefined,
                    K.indicator_3 => K.undefined
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            h = {   K.jsonmodel_type => K.resource,
                    K.title => K.undefined,
                    K.publish => true,
                    K.restrictions => false,
                    K.ead_id => K.undefined,
                    K.finding_aid_title => K.undefined,
                    K.finding_aid_filing_title => K.undefined,
                    K.finding_aid_date => K.undefined,
                    K.finding_aid_author => K.undefined,
                    K.finding_aid_language_note => K.undefined,
                    K.suppressed => false,
                    K.id_0 => K.undefined,
                    K.level => K.undefined,
                    K.finding_aid_language => K.undefined,
                    K.finding_aid_script => K.undefined,
                    K.finding_aid_status => K.undefined,
                    K.external_ids => [],
                    K.subjects => [{ K.ref => K.undefined }],
                    K.linked_events=>[],
                }
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            h = {   K.jsonmodel_type => K.top_container ,
                    K.resource => { 
                        K.ref => K.undefined
                    } ,
                    K.type => K.undefined ,       # 'box'
                    K.indicator => K.undefined ,  #  box sequence number
                    K.created_for_collection => K.undefined,
                    K.collection => []
                } 
            jsonmodel_H[ h[ K.jsonmodel_type ] ] = h
            
            return jsonmodel_H[ type ] if ( jsonmodel_H.has_key?( type ))
#           Stderr.puts "#{Stderr.lineno}: nil type #{type}"
            return nil      # the filter routine will skip the filter if nil is returned
        end
        
        def jsonmodel_filter__what_to_keep( jsonmodel_type )
            if ( jsonmodel_type == nil or jsonmodel_type == '' )
            then   
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "jsonmodel_type is nil or ''"
                raise
            end
            h = jsonmodel_H( jsonmodel_type )
            return nil if ( h == nil )
            h.merge!( { K.uri => '', K.ref => '', K.tree => '' } )
            return h
        end
        
        def nil_filter__what_to_throw_away( )
            h = {   K.created_by => '',
                    K.last_modified_by => '',
                    K.create_time => '',
                    K.system_mtime => '',
                    K.user_mtime => '' }
            return h
        end
        
        def filter_jsonmodel( jsonmodel_H )
            if ( not jsonmodel_H.is_a?( Hash )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.pp "jsonmodel_H is a #{jsonmodel_H.class} not a hash:", jsonmodel_H
                raise
            end
            if ( jsonmodel_H.has_key?( K.jsonmodel_type )) then
                jsonmodel_filter__what_to_keep = jsonmodel_filter__what_to_keep( jsonmodel_H[ K.jsonmodel_type ])
            end
            h = {}
            jsonmodel_H.each_pair do | k, v |
 #              puts "k = #{k}, v = #{v}, v.class = #{v.class}"
                if ( v.is_a?( Array )) then
                    a = v.map do | e |
                        if ( e.is_a?( Hash ) and e.has_key?( K.jsonmodel_type )) then
                            filter_jsonmodel( e )
                        else
                            e
                        end
                    end
                    h.merge!( { k => a } )
                elsif ( v.is_a?( Hash ) ) then
                    h.merge!( { k => filter_jsonmodel( v ) } )
                else
                    if ( jsonmodel_filter__what_to_keep ) then
                        h.merge!( { k => v } ) if ( jsonmodel_filter__what_to_keep.has_key?( k )) 
                    else
                        h.merge!( { k => v } ) if ( not nil_filter__what_to_throw_away.has_key?( k ))         
                    end
                end
            end
            return h
        end
        
        def read( filter_record_B = false )
            http_response_body_H = @http_calls_O.http_get( @uri )
 #          Stderr.puts "#{Stderr.lineno}"
 #          Stderr.pp "http_response_body_H:", http_response_body_H
 #          Stderr.pp "filter_jsonmodel_template_H:", filter_jsonmodel_template_H
            if ( ! ( http_response_body_H.has_key?( K.jsonmodel_type ) ) )
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Was expecting a jsonmodel_type in http_response_body"
                Stderr.puts "@uri = #{@uri}"
                Stderr.pp "http_response_body_H:", http_response_body_H
                raise
            end
            if ( filter_record_B ) then
#               Stderr.pp "Before:", http_response_body_H
                http_response_body_H = filter_jsonmodel( http_response_body_H )
#               Stderr.pp "After:", http_response_body_H
            end
#           Stderr.pp "http_response_body_H:", http_response_body_H
            return http_response_body_H
        end
        
        def store
            if (@record_H == nil or ( @record_H.has_key?( K.uri) and @record_H[ K.uri ] != @uri )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Store failed"
                Stderr.puts "Current @record_H[ K.uri ] != @uri"
                Stderr.puts "@uri = #{@uri}"
                Stderr.pp "Current @record_H:", @record_H
                raise
            end
            if ( $global_update ) then
                http_response_body_H = @http_calls_O.http_post_with_body( @uri, @record_H )
                if ( http_response_body_H[K.status] != 'Created' ) then 
                    Stderr.puts "#{Stderr.lineno}: =============================================="
                    Stderr.puts "Create failed"
                    Stderr.puts "@uri = #{@uri}"
                    Stderr.puts "@record_H:", @record_H
                    Stderr.pp "http_response_body_H:", http_response_body_H
                    raise
                end
            else
                http_response_body_H = {K.uri => "NO UPDATE MODE"}
            end
            return http_response_body_H
        end

        def delete
            if (@record_H == nil or not ( @record_H.has_key?( K.uri) and @record_H[ K.uri ] == @uri )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Delete failed"
                Stderr.puts "Current @record_H[ K.uri ] != @uri"
                Stderr.puts "@uri = #{@uri}"
                Stderr.pp "Current @record_H:", @record_H
                raise
            end
            if ( $global_update ) then
                http_response_body_H = @http_calls_O.http_delete( @uri, { } )
                if ( http_response_body_H[K.status] != 'Deleted' ) then 
                    Stderr.puts "#{Stderr.lineno}: =============================================="
                    Stderr.puts "Delete failed"
                    Stderr.puts "@uri = #{@uri}"
                    Stderr.pp "http_response_body_H:", http_response_body_H
                    raise
                end
            else
                http_response_body_H = {K.uri => "NO UPDATE MODE"}
            end
            return http_response_body_H
        end
    end

    class Http_Calls
    
        require "net/http"
        require 'uri'
        require "json"
    
        def initialize( p1_aspace_O )
            if ( p1_aspace_O.class != ASpace ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a ASpace class object"
                raise
            end    
            @aspace_O = p1_aspace_O
        end
        
        def http_get( p1_uri, p2_params = { } )
        #   Stderr.pov( uri ) 
                
            uri = URI.parse( "#{@aspace_O.api_uri_base}#{p1_uri}" )
            uri.query = URI.encode_www_form( p2_params )
            http = Net::HTTP.new(uri.host, uri.port)
        #   http.set_debug_output( $stderr )
        #   Stderr.pov( http )
                
            headers = { "Content-type" => "application/json", "X-ArchivesSpace-Session" => @aspace_O.session }
            response = http.request( Net::HTTP::Get.new( uri.request_uri, headers ))
        #   Stderr.pov( response )
        #   Stderr.pom( response )
        #   Stderr.pp response.to_H   # This defaults to printing the headers
        #   response.each_header do |key, value|
        #       Stderr.puts "#{key} => #{value}"
        #   end
            if ( response.code != "200" ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "p1_uri = #{p1_uri}"
                Stderr.puts "p2_params = #{p2_params}"
                Stderr.puts "response.code = #{response.code}"
                Stderr.puts "response.body:" , response.body
                raise
            end
            response_body = JSON.parse( response.body )
            return response_body
        end           
        
        def http_post_with_params( p1_uri, p2_params = { } )  
            uri = URI.parse("#{@aspace_O.api_uri_base}/#{p1_uri}")
            uri.query = URI.encode_www_form( p2_params )  # Params are after the ? in the URL
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )    
            if ( @aspace_O.session == nil ) then
                headers = { "Content-type" => "application/json" }
            else
                headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}
            end
            response_O = http.request( Net::HTTP::Post.new( uri.request_uri, headers ))    
            if ( response_O.code != "200" ) then 
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
            return response_body
        end

        def http_post_with_body( p1_uri, p2_input_H )     
            uri = URI.parse("#{@aspace_O.api_uri_base}#{p1_uri}")       
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )      
            headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}
            input_O = Net::HTTP::Post.new( uri.request_uri, headers )
            input_O.body = p2_input_H.to_json
            response_O = http.request( input_O )
            if ( response_O.code != "200" ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.puts "p1_uri = #{p1_uri}"
                Stderr.puts "p2_input_H:", p2_input_H
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
        #   Stderr.pp "response_body", response_body
            return response_body;
        end 
        
        def http_delete( p1_uri, p2_params = { } )  
            uri = URI.parse("#{@aspace_O.api_uri_base}/#{p1_uri}")
            uri.query = URI.encode_www_form( p2_params )  # Params are after the ? in the URL
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )    
            headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}  
            response_O = http.request( Net::HTTP::Delete.new( uri.request_uri, headers ))
            if ( response_O.code != "200" ) then 
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
            return response_body
        end
    end
end



