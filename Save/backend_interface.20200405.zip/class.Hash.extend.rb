class ::Hash

def deep_keys_to_a
    h_map_output_A = self.map do |k, v|
#       puts "k = #{k}, v = #{v}"
#       puts
        va = v.is_a?( Array ) ? v : [ v ]
        if ( va == [] ) then
            r = k
#           puts "Value is []        :  #{r} => []"
#           puts
            r
        else
            y_map_output_A = va.map do |e|
                if (e.is_a?( Hash ))
#                   puts "Into recusion, hash:  #{k} => #{e}"
#                   puts
                    r = [k, e.deep_keys_to_a]
#                   puts "Return from recusion: #{r}"
#                   puts
                    r
                else
                    r = k
#                   puts "Value wasn't a hash:  #{r} => #{e}"
#                   puts
                    r
                end
            end
    #       puts "y_map_output_A = #{y_map_output_A}"
            y_map_output_A = y_map_output_A.shift
        end
    end 
#   puts "h_map_output_A = #{h_map_output_A}"
#   puts "RETURN ==========================="
#   puts
    h_map_output_A
end


    def deep_merge(second)
#       https://stackoverflow.com/a/30225093
        merger = proc { |_, v1, v2| Hash === v1 && Hash === v2 ? v1.merge(v2, &merger) : Array === v1 && Array === v2 ? v1 | v2 : [:undefined, nil, :nil].include?(v2) ? v1 : v2 }
        merge(second.to_h, &merger)
    end


end

