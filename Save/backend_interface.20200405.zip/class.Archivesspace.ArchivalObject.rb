=begin

Abbreviations,  AO/ao = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative

=end

class ASpace

    class AO_Record_Buf < Record_Buf       
        def initialize( p1_res_O, p2_AO_identifier = nil )
            if ( p1_res_O.class != Resource_Record_Buf ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a Repository class object"
                raise
            end    
            aspace_O = p1_res_O.aspace_O
            super( aspace_O )
            @rep_O = p1_res_O.rep_O
            @res_O = p1_res_O
            if ( p2_AO_identifier == nil ) then
                @num = nil
                @uri = nil
            else
                if ( p2_AO_identifier.integer? ) then
                    @num = p2_AO_identifier
                    @uri = "#{@rep_O.uri}/archival_objects/#{@num}"
                else
                    stringer = "#{@rep_O.uri}/archival_objects"
                    if ( stringer == p2_AO_identifier[ 0 .. stringer.maxindex ]) then
                        @uri = p2_AO_identifier
                        @num = p2_AO_identifier.sub( /^.*\//, '' )
                        if (! @num.integer? ) then
                            Stderr.puts "#{Stderr.lineno}: =============================================="
                            Stderr.puts "Invalid param2: #{p2_AO_identifier}"
                            raise
                        end
                    end
                end
            end
        end
        attr_reader :rep_O, :res_O, :num, :uri, :record_H
        
        def create( p1_level )
            if ( p1_level.downcase.in? [ K.series, K.subseries ] ) then
                h = { 
                        K.jsonmodel_type => K.archival_object ,
                        K.resource => { 
                            K.ref => @res_O.uri
                        } ,
                        K.parent => { 
                            K.ref => "UNDEFINED"    
                        } ,
                        K.title => "UNDEFINED" ,   #  "Southern Pacific" 
                        K.level => p1_level ,
                        K.publish =>  true,
#############
                        K.dates => [] ,
                        K.notes => [] ,
                        K.instances=> { }                                
                    } 
            elsif ( p1_level.downcase.in? [ K.file ] ) then
                h = { 
                        K.jsonmodel_type => K.archival_object ,
                        K.resource => { 
                            K.ref => @res_O.uri 
                        } ,
                        K.parent => { 
                            K.ref => "UNDEFINED"    
                        } ,
                        K.title => "UNDEFINED" ,   #  "Southern Pacific" 
                        K.level => p1_level ,
                        K.publish =>  true ,
                        K.dates => [] ,
                        K.notes => [] ,
                        K.instances=> { }                                
                    } 
            else
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Invalid p1_level: #{p1_level}"
                raise
            end
            @record_H.merge!( h )
            @cant_change_A << [ K.level ]
            return self
        end

        def read
            @record_H = super
            if ( @record_H [K.resource][K.ref] != @res_O.uri ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Archival_object doesn't belong to current Resource."
                Stderr.puts "@record_H [K.resource][K.ref] != @res_O.uri"
                Stderr.puts "#{@record_H [K.resource][K.ref]} != #{@res_O.uri}"
                raise
            end
            return self
        end
         
        def store( )
        #   Stderr.pp "@record_H:", @record_H            
            if (!(   @record_H[K.jsonmodel_type] and @record_H[K.jsonmodel_type] == K.archival_object)) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting @record_H[K.jsonmodel_type] == K.archival_object";
                Stderr.pp "@record_H:", @record_H
                raise
            end 
            if (!(   @record_H[K.resource][K.ref] and @record_H[K.resource][K.ref] != '')) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting an @record_H[K.resource][K.ref] value";
                Stderr.pp "@record_H:", @record_H
                raise
            end
            if ( @record_H.has_key?(K.parent)) then
                if ( @record_H[K.parent].respond_to?(:to_H) and @record_H[K.parent].has_key?(K.ref)) then
                    if ( !(  @record_H[K.parent][K.ref] =~ %r"^#{@rep_O.uri}/(archival_objects|resources)" \
                           or(  @record_H[K.parent][K.ref] == "NO UPDATE MODE" and ! $global_update)))
                        Stderr.puts "#{Stderr.lineno}: =========================================="
                        Stderr.puts "@record_H[K.parent][K.ref] =~ |#{@rep_O.uri}/(archival_objects|resources)|"
                        Stderr.puts "@record_H[K.parent][K.ref] = #{@record_H[K.parent][K.ref]}"
                        Stderr.pp "@record_H:", @record_H
                        raise
                    end
                end
            end
            if (!(  @record_H[K.title] and @record_H[K.title] != 'UNDEFINED')) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting an @record_H[K.title] value";
                Stderr.pp "@record_H:", @record_H
                raise
            end
            if (!(  @record_H[K.level] and @record_H[ K.level].in? [K.series, K.subseries, K.file])) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting a specific value in @record_H[K.level]";
                Stderr.pp "@record_H:", @record_H
                raise
            end
            if ( @record_H [K.resource][K.ref] != @res_O.uri ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Archival_object doesn't belong to current Resource."
                Stderr.puts "@record_H [K.resource][K.ref] != @res_O.uri"
                Stderr.puts "#{@record_H [K.resource][K.ref]} != #{@res_O.uri}"
                raise
            end
            
            if ( @uri == nil ) then
                @uri = "#{@rep_O.uri}/archival_objects"
                http_response_body_H = super
                Stderr.puts "#{Stderr.lineno}: Created ArchivalObject, uri = #{http_response_body_H[ K.uri ]}";
            else
                Stderr.puts "#{Stderr.lineno}: I shouldn't be updating an ArchivalObject"
                raise
                http_response_body_H = super
                Stderr.puts "#{Stderr.lineno}: Updated ArchivalObject, uri = #{http_response_body_H[ K.uri ]}";
            end
            @uri = http_response_body_H[ K.uri ] 
            return self
        end
    end    


    class AO_Query    
        def initialize( p1_rep_O )
            @rep_O = p1_rep_O
            @uri = "#{p1_rep_O.uri}/find_by_id/archival_objects"
            @result = nil
        end
        attr_reader :result

        def get_H_of_A_of_AO_ref__find_by_ref( p1_AO_ref_A )
            http_response_body = ASpace::Http_Calls.new( @rep_O.aspace_O ).http_get( @uri, { 'ref_id[]' => p1_AO_ref_A } )
            if ( http_response_body[K.archival_objects].length < 1 ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Unable to find Archival_Object with ref='#{p1_AO_ref_A}'"
                Stderr.pp K.http_response_body, http_response_body
        #       Note:  The ref are the strings that look like this:  75f47d3454c79e8d2f9a180ae35779a6
        #              It's NOT the resource number.
                raise
            end		
            @result = http_response_body
            return self
        end
    end
end 
