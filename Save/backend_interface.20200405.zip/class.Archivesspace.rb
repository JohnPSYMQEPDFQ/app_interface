=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative

=end


class ASpace

    require 'pp'
    require 'module.Stderr.rb'
    require 'class.Array.extend.rb'
    require 'class.String.extend.rb'
    require 'class.Hash.extend.rb'
    require 'module.ArchivesSpace.Konstants.rb'

    def initialize()
        @session = 'not_logged_in'
        @api_uri_base = nil
#       Stderr.puts "================ In Aspace:initialize self.session=#{self.session}"
    end
    attr_reader :api_uri_base, :session
    attr_writer :api_uri_base
        
	def login( p1_userid , p2_password )
		if ( @api_uri_base == nil ) then
			Stderr.puts "#{Stderr.lineno}: =============================================="
			Stderr.puts "Set it with the ASpace#api_uri_base= method"
			raise 
		end
		@session = nil
		@uri = "/users/#{p1_userid}/login"
		http_response_body_H = ASpace::Http_Calls.new( self ).http_post_with_params( @uri, { K.password => p2_password } )
		@session = http_response_body_H[ K.session ]
	#   Stderr.puts "session = #{@session}"
		return http_response_body_H
	end
		
    class Buffer_Base
         
        def initialize(  )
            @record_H = Hash.new( )
            @cant_change_A = [ ]
            @cant_change_A << K.jsonmodel_type 
        end
        attr_reader :cant_change_A
        #  Shouldn't be an attr_reader :record_H here.
             
        def hash_comp_key_type( h_before, h_after )
#           Stderr.puts "Before: #{h_before}"
#           Stderr.puts "After:  #{h_after}"
            h_before.each_pair do | k, v |
#               Stderr.puts "start loop: k = #{k}, v = #{v}"
                if ( k == K.parent ) then
                    next if ( h_after.has_key?( k ) and h_after[ k ].is_a?( String ) and h_after[ k ] == '' ) 
                else
                    return { k => v } if ( ! h_after.has_key? (k))
                    return { k => v } if ( ! v.class == h_after[ k ].class )
                end
                if ( v.is_a? ( Hash )) then
                    return { k => v } if ( ! hash_comp_key_type( h_before[ k ], h_after[ k ]) == { } )
                end
            end
            return {}
        end
        private :hash_comp_key_type
        
        def record_H=( set_values_H )
            set_values_H.each do |k, v|
                if (k.in?( @cant_change_A )) then
                    Stderr.puts "#{Stderr.lineno}: ======================================"
                    Stderr.puts "Key #{k} can't be changed."
                    raise
                end
            end
            before_rec_H = Hash.new.merge( @record_H )
            @record_H = @record_H.deep_merge( set_values_H )  
            h = hash_comp_key_type( before_rec_H, record_H )
            if ( h != {} )
                Stderr.puts "#{Stderr.lineno}: ======================================"
                Stderr.puts "Invalid (new?, mistyped?) hash key: #{h}"
                Stderr.puts "save_rec_deep_keys_to_a = #{save_rec_deep_keys_to_a}"
                Stderr.puts "@record_H.deep_keys_to_a = #{@record_H.deep_keys_to_a}"
                raise
            end
            
            if ( before_rec_H.keys != @record_H.keys ) then
                Stderr.puts "#{Stderr.lineno}: ======================================"
                Stderr.puts "Invalid (new?, mistyped?) hash key: #{set_values_H}"
                Stderr.puts "save_rec_deep_keys_to_a = #{save_rec_deep_keys_to_a}"
                Stderr.puts "@record_H.deep_keys_to_a = #{@record_H.deep_keys_to_a}"
                raise
            end
            return @record_H
        end
    end
    	
    class Fragment_Buf < Buffer_Base
        def initialize( p1_proc )
            super( )
            @record_H = method(p1_proc).call 
        end
        attr_reader :record_H
     
        def mixed_materials_IT       
            h =  {
                    K.instance_type =>K.mixed_materials ,
                    K.sub_container => {
                        K.top_container => {
                            K.ref => "UNDEFINED"      # Ref to top_container, eg. /repositories/2/top_containers/98
                        } ,
                        "type_2" => "UNDEFINED" ,     # 'folder'
                        "indicator_2" => "UNDEFINED"  #  Folder identifier, eg a sequence num
                    }
                }
            @record_H.merge!( h )
            @cant_change_A << [ K.instance_type ] 
            return @record_H
        end

        def single_date           
            h = {
                  K.label => "UNDEFINED", 
                  K.date_type => K.single, 
                  K.begin => "UNDEFINED" 
                }
            @record_H.merge!( h )
            @cant_change_A << [ K.date_type ] 
            return @record_H
        end
       
        def inclusive_dates  
            h =  {
                    K.label => "UNDEFINED", 
                    K.date_type => K.inclusive, 
                    K.begin => "UNDEFINED", 
                    K.end => "UNDEFINED"
                 }
            @record_H.merge!( h )
            @cant_change_A << [ K.date_type ] 
            return @record_H
        end
        
        def note_singlepart   
            h =  {
                    K.jsonmodel_type => K.note_singlepart,
                    K.ingest_problem => "",
                    K.type => "UNDEFINED",    #(physloc)
                    K.publish =>  true,
                    K.content => [ ],
                    K.label => "",
                    K.persistent_id => ""
                }
            @record_H.merge!( h )
            return @record_H
        end
        
        def note_multipart         
            h = {
                    K.jsonmodel_type => K.note_multipart, 
                    K.ingest_problem => "", 
                    K.persistent_id => "", 
                    K.label => "", 
                    K.type => "UNDEFINED", #(processinfo)
                    K.subnotes =>  [  ]			
                }
            @record_H.merge!( h )
            return @record_H
        end
        
        def note_text 
            h = {
                    K.jsonmodel_type => K.note_text, 
                    K.ingest_problem => "", 
                    K.content => "UNDEFINED"
                }
            @record_H.merge!( h )
            return @record_H
        end
    end
end



