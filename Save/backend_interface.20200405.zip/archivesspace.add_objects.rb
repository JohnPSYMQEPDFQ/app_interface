=begin

Abbreviations,  AO = archival object (Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative


Usage: add_objects.rb --help

To attach the records in FILE to the "Resource Record", only the --as-resource-num option is needed.
To attach the records to a specific AO, enter the --as-resource-num option along with the --as-ao-ref
of the child AO. The --ref is the long unique-id of the record.


The input FILE has the following three formats( JSONized ):

        1 = {
              'record' =>
                {
                  'level' => 'AO level',    # Only "series", "subseries", and "file" are supported 
                  'title' => '',            # the AO title field.
-optional-        'dates' => [ ],           # An array of AO date hashes, single or inclusive
-optional-        'notes' => [ ]            # An array of AO note hashes, singlepart or miltipart
-optional-        'container_format_1' =>   # References to TC of "type > indicator", creates the TC if needed.
                    {
                      'TC_type'      => 'VALUE'     # eg. 'box'
                      'TC_indicator' => 'n'         # Box number (must be a number)
                      'SC_type'      => 'VALUE'     # eg. 'folder'
                      'SC_indicator' => 'STRING'    # Anything identifing the folder
                    }
                }
            }
  
        2 = {
              'indent' =>                   
                {
                  'right' => 'Any text'        # Text only used for debugging
                }
            }
  
        3 = {
              'indent' =>                   
                {
                  'left' => 'Any text'       # Text only used for debugging
                }
            }

    Record format 1 is the data record.  As-of 3/18/2020 only the "series", "subseries", and "file" AO-level types
    were supported ( ie tested )

    Record format 2 causes all the records following the "indent => right" record to be attached to the record PRIOR to 
    the "indent => right" record.

    Record format 3 causes all the records following the "indent => left" record to be attached to the record PRIOR to
    the previous "indent => right" record. At the end of the program run, an "indent counter" is displayed, which should
    be 0 IF the number of right-dents equals the number left-dents.  Sometimes, there's no final indent-left tho.

=end

require "json"
require 'pp'
require 'optparse'

require 'class.Array.extend.rb'
require 'class.String.extend.rb'
require 'module.Stderr.rb'
require 'class.Archivesspace.rb'
require 'class.ArchivesSpace.http_calls.rb'
require 'class.Archivesspace.ArchivalObject.rb'
require 'class.Archivesspace.Repository.rb'
require 'class.Archivesspace.TopContainer.rb'
require 'class.Archivesspace.Resource.rb'

def get_A_of_TC_H( p1_res_buf_O, p2_TC_num_A )
    array_of_TC_H = [ ]
    p2_TC_num_A.each { |each_TC_num|
        array_of_TC_H << ASpace::TC_Record_Buf.new( p1_res_buf_O, each_TC_num ).read.record_H
    }
    return array_of_TC_H
end

def get_A_of_TC_H__for_all_unused_AND_for_this_resource( p1_res_buf_O, p2_array_of_TC_H )
    array_of_TC_H__unused_and_this_resource=[ ]
    p2_array_of_TC_H.each { |each_TC_H|
        if ( each_TC_H.key?( K.collection ) && each_TC_H[ K.collection ].count > 0 ) then
            each_TC_H[ K.collection ].each { |ref_A|
                if ( ref_A.key?( K.ref ) ) then
                    if ( ref_A[ K.ref ] == p1_res_buf_O.uri ) then
                        array_of_TC_H__unused_and_this_resource << [ '', each_TC_H ]
                    end
                end
            }
        else
            array_of_TC_H__unused_and_this_resource << [ K.unused, each_TC_H ]
        end
    }
    return array_of_TC_H__unused_and_this_resource
end

def get_A_of_AO_ref( p1_hash_of_AO_ref_A )
    array_of_AO_ref= [ ]
    p1_hash_of_AO_ref_A[ K.archival_objects ].each do |each_A_element| 
        array_of_AO_ref<< each_A_element[ K.ref ]
    end
#   Stderr.pp "#{Stderr.lineno}: array_of_AO_ref:", array_of_AO_ref
    return array_of_AO_ref
end
    

BEGIN {}
END {}

myself_name = File.basename( $0 )
api_uri_base = "http://localhost:8089"

cmdln_option = { "as-repository-num" => 2  ,
                 "as-resource-num" => nil  ,
                 "as-ao-ref" => nil  ,
                 "delete-TC-only" => false ,
                 "delete-tc-only" => false ,
                 "update" => false ,
                 'last_record_num' => nil}
OptionParser.new do |option|
    option.banner = "Usage: #{myself_name} [ options ] FILE"
    option.on( "--as-repository-num n", OptionParser::DecimalInteger, "Repository number ( default = 2 )" ) do |opt_arg|
        cmdln_option[ 'as-repository-num' ] = opt_arg
    end
    option.on( "--as-resource-num n", OptionParser::DecimalInteger, "Resource number ( required )" ) do |opt_arg|
        cmdln_option[ 'as-resource-num' ] = opt_arg
    end
    option.on( "--as-ao-ref x", "Archival Object ReferenceID ( optional, but must be member of suppled Resource number )" ) do |opt_arg|
        cmdln_option[ 'as-ao-ref' ] = opt_arg
    end
    option.on( "--delete-TC-only", "Delete TC records only" ) do |opt_arg|
        cmdln_option[ 'delete-TC-only' ] = true
    end
    option.on( "--delete-tc-only", "Delete TC records only" ) do |opt_arg|
        cmdln_option[ 'delete-TC-only' ] = true
    end
    option.on( "--update", "Do updates" ) do |opt_arg|
        cmdln_option[ 'update' ] = true
    end
    option.on( "--last-record-num n", OptionParser::DecimalInteger, "Stop after record N" ) do |opt_arg|
        cmdln_option[ 'last-record-num' ] = opt_arg
    end
    option.on( "-h","--help" ) do
        Stderr.puts option
        exit
    end
end.parse!  # Bang because ARGV is altered
#p cmdln_option
#p ARGV
if ( cmdln_option[ 'as-repository-num' ] ) then
    repository_num = cmdln_option[ 'as-repository-num' ]
else
    Stderr.puts "The --as-repository-num option is required."
    raise
end
if ( cmdln_option[ 'as-resource-num' ] ) then
    resource_num = cmdln_option[ 'as-resource-num' ]
else
    Stderr.puts "The --as-resource-num option is required."
    raise
end
if ( cmdln_option[ 'as-ao-ref' ] ) then
    cmdln_AO_ref = cmdln_option[ 'as-ao-ref' ]      
else
    cmdln_AO_ref = nil
end
if ( cmdln_option[ 'last-record-num' ] ) then
    last_record_num = cmdln_option[ 'last-record-num' ]      
else
    last_record_num = nil
end
$global_update=cmdln_option[ 'update' ] 
delete_TC_records_only=cmdln_option[ 'delete-TC-only' ] 

aspace_O = ASpace.new
aspace_O.api_uri_base = api_uri_base
aspace_O.login( "admin", "admin" )
#Stderr.pom(aspace_O)
#Stderr.pov(aspace_O)
rep_O = ASpace::Repository.new( aspace_O, repository_num )
#Stderr.pom(rep_O)
#Stderr.pov(rep_O)
res_buf_O = ASpace::Resource_Record_Buf.new( rep_O, resource_num ).read
#Stderr.pom(res_buf_O)
#Stderr.pov(res_buf_O)

if ( cmdln_AO_ref ) then
    initial_parent_AO_uri = get_A_of_AO_ref( ASpace::AO_Query.new( rep_O ).get_H_of_A_of_AO_ref__find_by_ref( [ cmdln_AO_ref ] ).result ) [ 0 ]
    Stderr.puts "#{Stderr.lineno}: initial_parent_AO_uri = #{initial_parent_AO_uri}"
    initial_parent_AO_H = ASpace::AO_Record_Buf.new(res_buf_O, initial_parent_AO_uri).read.record_H
else
    initial_parent_AO_H = res_buf_O.record_H
    initial_parent_AO_uri = initial_parent_AO_H[ K.uri ]
    Stderr.puts "#{Stderr.lineno}: initial_parent_AO_uri = #{initial_parent_AO_uri}"
end

array_of_TC_H = get_A_of_TC_H( res_buf_O, ASpace::TC_Query.new( rep_O ).get_A_of_TC_nums( { 'all_ids' => 'true' } ).result )
#Stderr.pp "#{Stderr.lineno}: array_of_TC_H = ", array_of_TC_H
array_of_TC_H__all_unused_AND_for_this_resource = get_A_of_TC_H__for_all_unused_AND_for_this_resource( res_buf_O, array_of_TC_H )
#Stderr.pp "#{Stderr.lineno}: array_of_TC_H__all_unused_AND_for_this_resource = ", array_of_TC_H__all_unused_AND_for_this_resource

hash_of_TC_uri__by_type_indicator = {}
array_of_TC_H__all_unused_AND_for_this_resource.each do |element|
    each_TC_H = element[ 1 ]
#   Stderr.pp each_TC_H
    if ( element[ 0 ] == K.unused ) then
        Stderr.puts "#{Stderr.lineno}: Delete top_container: #{each_TC_H[ K.uri ]}"
        ASpace::TC_Record_Buf.new( res_buf_O, each_TC_H[ K.uri ] ).delete
    else
        if ( each_TC_H.key?( K.type ) and each_TC_H.key?( K.indicator )) then
            stringer=each_TC_H[ K.type ] + each_TC_H[ K.indicator ]
            if ( hash_of_TC_uri__by_type_indicator.key?( stringer ) ) then
                Stderr.puts "#{Stderr.lineno}: Duplicate each_TC_H 'type+indicator' #{stringer}, K.uri=#{each_TC_H[ K.uri ]}"
                next
            end
            hash_of_TC_uri__by_type_indicator[ stringer ] = each_TC_H[ K.uri ]
        end   
    end 
end
if (delete_TC_records_only) then
    exit
end

#Stderr.pp "hash_of_TC_uri__by_type_indicator:", hash_of_TC_uri__by_type_indicator

indent_cnt = 0
file_cnt = 0
last_AO_uri_created = ""
parent_ref_stack_A = [ initial_parent_AO_uri ]

for argv in ARGV do
    File.foreach( argv ) do |input_record_json|
        if ( last_record_num != nil and $. > last_record_num ) then 
            break
        end
        input_record_json.chomp!
        if ( input_record_json.match?( /^\s*$/ ) ) then
            next
        end
        input_record_H = JSON.parse( input_record_json )

        if ( input_record_H.key?( K.indent ) ) then
            Stderr.puts "#{Stderr.lineno}: Rec:#{$.}: '#{input_record_json}'"
            if ( input_record_H[ K.indent ][ 0 ] == K.right ) then
                indent_cnt += 1
                parent_ref_stack_A.push( last_AO_uri_created )
                next
            end
            if ( input_record_H[ K.indent ][ 0 ] == K.left ) then
                indent_cnt += -1
                last_AO_uri_created=parent_ref_stack_A.pop( 1 )[ 0 ]
                next
            end
        end

        if ( input_record_H.key?( K.record ) ) then
            if ( input_record_H[ K.record ][ K.level ].downcase.in?( [ K.series, K.subseries ] ) ) then
                Stderr.puts "#{Stderr.lineno}: Rec:#{$.}: '#{input_record_json}'"
                ao_buf_O = ASpace::AO_Record_Buf.new( res_buf_O ).create( input_record_H[ K.record ][ K.level ] )
                if ( ao_buf_O.record_H[ K.resource][K.ref] == parent_ref_stack_A[ parent_ref_stack_A.maxindex ] ) then
                    ao_buf_O.record_H = { K.parent => '' }
                else
                    ao_buf_O.record_H = { K.parent => { K.ref => parent_ref_stack_A[ parent_ref_stack_A.maxindex ] }} 
                end
                ao_buf_O.record_H = { K.title => input_record_H[ K.record ][ K.title ] }
                ao_buf_O.store
                last_AO_uri_created = ao_buf_O.uri
                next
            end
            if ( input_record_H[ K.record ][ K.level ] == K.file ) then
                file_cnt += 1
                Stderr.puts "#{Stderr.lineno}: Rec:#{$.}: '#{input_record_json}'"
                ao_buf_O = ASpace::AO_Record_Buf.new( res_buf_O ).create( input_record_H[ K.record ][ K.level ] )
                if ( ao_buf_O.record_H[ K.resource][K.ref] == parent_ref_stack_A[ parent_ref_stack_A.maxindex ] ) then
                    ao_buf_O.record_H = { K.parent => '' }
                else
                    ao_buf_O.record_H = { K.parent => { K.ref => parent_ref_stack_A[ parent_ref_stack_A.maxindex ] }} 
                end
                ao_buf_O.record_H = { K.title => input_record_H[ K.record ][ K.title ] }
                if ( input_record_H[ K.record ].key?( 'AO_date_array' ) ) then
                    ao_buf_O.record_H = { K.dates => input_record_H[ K.record ][ 'AO_date_array' ] }
                end
                if ( input_record_H[ K.record ].key?( 'AO_note_array' ) ) then
                    ao_buf_O.record_H = { K.notes => input_record_H[ K.record ][ 'AO_note_array' ] }
                end
                if ( input_record_H[ K.record ].key?( 'container_format_1' ) ) then
                    type      = "#{input_record_H[ K.record ]['container_format_1']['TC_type']}"
                    indicator = "#{input_record_H[ K.record ]['container_format_1']['TC_indicator']}"
                    unique_TC_key  = "#{type}#{indicator}"
                    if ( ! hash_of_TC_uri__by_type_indicator.key?( unique_TC_key ) ) then
                        tc_buf_O = ASpace::TC_Record_Buf.new( res_buf_O ).create
                        tc_buf_O.record_H = { K.type => type }
                        tc_buf_O.record_H = { K.indicator => indicator }
                        tc_buf_O.store
                        hash_of_TC_uri__by_type_indicator[ unique_TC_key ] = tc_buf_O.uri
                        Stderr.pp "#{Stderr.lineno}: hash_of_TC_uri__by_type_indicator:", hash_of_TC_uri__by_type_indicator
                    end
    
                    mm_frag_O = ASpace::Fragment_Buf.new( :mixed_materials_IT )
                    mm_frag_O.record_H = { K.sub_container => { K.top_container => { K.ref =>  hash_of_TC_uri__by_type_indicator[ unique_TC_key ] }}}
                    mm_frag_O.record_H = { K.sub_container => { 'type_2' => input_record_H[ K.record ]['container_format_1']['SC_type'] }}
                    mm_frag_O.record_H = { K.sub_container => { 'indicator_2' => input_record_H[ K.record ]['container_format_1']['SC_indicator'] }}
                    
                    ao_buf_O.record_H = { K.instances => [ mm_frag_O.record_H ] }
                end

                ao_buf_O.store
                last_AO_uri_created = ao_buf_O.uri
                next
            end
        end
        Stderr.puts "#{Stderr.lineno}: I should't be here!"
        Stderr.pp "#{$.}: input_record_H:", input_record_H
        raise
    end
end
Stderr.puts "file count = #{file_cnt}"
Stderr.puts "indent count = #{indent_cnt}"
Stderr.pp "hash_of_TC_uri__by_type_indicator:", hash_of_TC_uri__by_type_indicator 

