=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
            AS = ArchivesSpace
            IT = instance type
            TC = top container
            SC = Sub-container
            _H = Hash
            _A = Array
            _I = Index(of Array)
            _O = Object
           _0R = Zero Relative

=end

class ASpace     


    class TC_Record_Buf < Record_Buf

        def initialize( p1_res_O, p2_TC_identifier = nil )
            if ( p1_res_O.class != Resource_Record_Buf ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a Repository class object, it's: '#{p1_rep_O.class}'"
                raise
            end    
            @aspace_O = p1_res_O.aspace_O
            super( @aspace_O )
            @rep_O = p1_res_O.rep_O
            @res_O = p1_res_O
            if ( p2_TC_identifier == nil ) then
                @num = nil
                @uri = nil
            else
                if ( p2_TC_identifier.integer? ) then
                    @num = p2_TC_identifier
                    @uri = "#{@rep_O.uri}/top_containers/#{@num}"
                else
                    stringer = "#{@rep_O.uri}/top_containers"
                    if ( stringer == p2_TC_identifier[ 0 .. stringer.maxindex ]) then
                        @uri = p2_TC_identifier
                        @num = p2_TC_identifier.sub( /^.*\//, '' )
                        if (! @num.integer? ) then
                            Stderr.puts "#{Stderr.lineno}: =============================================="
                            Stderr.puts "Invalid param2: #{p2_TC_identifier}"
                            raise
                        end
                    end
                end
            end
        end
        attr_reader :aspace_O, :rep_O, :res_O, :num, :uri, :record_H
        
        def create( )      
            h = {
                K.jsonmodel_type => K.top_container ,
                K.resource => { 
                    K.ref => @res_O.uri
                } ,
                K.type => "UNDEFINED" ,       # 'box'
                K.indicator => "UNDEFINED" ,  #  box sequence number
                K.created_for_collection => @res_O.uri
            } 
            @record_H.merge!( h )
            return self
        end
        
        def read
            @record_H = super
            return self
        end

        def store( )
        #   Stderr.pp "@record_H:", @record_H
        
            if (!(  @record_H[K.jsonmodel_type] and @record_H[K.jsonmodel_type] == K.top_container)) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting @record_H[K.jsonmodel_type] == K.top_container";
                raise
            end 
            if (!(  @record_H[K.type] and @record_H[K.type] != '')) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting an @record_H[K.type] value";
                raise
            end
            if (!(  @record_H[K.indicator] and @record_H[K.indicator] != 'UNDEFINED')) then 
                Stderr.puts "#{Stderr.lineno}: I was expecting an @record_H[K.indicator] value";
                raise
            end
            if ( @record_H [K.resource][K.ref] != @res_O.uri ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Top_Container doesn't belong to current Resource."
                Stderr.puts "@record_H [K.resource][K.ref] != @res_O.uri"
                Stderr.puts "#{@record_H [K.resource][K.ref]} != #{@res_O.uri}"
                raise
            end
            if ( @uri == nil ) then
                @uri = "#{@rep_O.uri}/top_containers"
                http_response_body_H = super
                Stderr.puts "#{Stderr.lineno}: Created TopContainer, uri = #{http_response_body_H[ K.uri ]}"
            else
                Stderr.puts "#{Stderr.lineno}: I shouldn't be updating a TopContainer"
                raise
                http_response_body_H = super
                Stderr.puts "#{Stderr.lineno}: Updated top_container, uri = #{http_response_body_H[ K.uri ]}"
            end
            @uri = http_response_body_H[ K.uri ] 
            return self
        end
            
        def delete( )
            read()
            if ( @record_H.has_key?( K.resource ) and @record_H [ K.resource ].has_key?( K.ref )) then
                if ( @record_H [ K.resource ][ K.ref ] != @res_O.uri ) then
                    Stderr.puts "#{Stderr.lineno}: =============================================="
                    Stderr.puts "Top_Container doesn't belong to current Resource."
                    Stderr.puts "@record_H [K.resource][K.ref] != @res_O.uri"
                    Stderr.puts "#{@record_H [K.resource][K.ref]} != #{@res_O.uri}"
                    raise
                end
            end
            http_response_body_H = super
            return http_response_body_H
        end	
    end
    

    class TC_Query
        def initialize( p1_rep_O )
            @rep_O = p1_rep_O
            @uri = "#{p1_rep_O.uri}/top_containers"    
            @result = nil
        end
        attr_reader :result
  
        def get_A_of_TC_nums( p1_params )
			http_response_body = ASpace::Http_Calls.new( @rep_O.aspace_O ).http_get( @uri, p1_params )
            @result = http_response_body
			return self
        end
    end
end

