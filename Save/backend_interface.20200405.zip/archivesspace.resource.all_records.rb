=begin

Abbreviations,  AO = archival object (Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative


Usage: add_objects.rb --help

To attach the records in FILE to the "Resource Record", only the --as-resource-num option is needed.
To attach the records to a specific AO, enter the --as-resource-num option along with the --as-ao-ref
of the child AO. The --ref is the long unique-id of the record.


The input FILE has the following three formats( JSONized ):

        1 = {
              'record' =>
                {
                  'level' => 'AO level',    # Only "series", "subseries", and "file" are supported 
                  'title' => '',            # the AO title field.
-optional-        'dates' => [ ],           # An array of AO date hashes, single or inclusive
-optional-        'notes' => [ ]            # An array of AO note hashes, singlepart or miltipart
-optional-        'container_format_1' =>   # References to TC of "type > indicator", creates the TC if needed.
                    {
                      'TC_type'      => 'VALUE'     # eg. 'box'
                      'TC_indicator' => 'n'         # Box number (must be a number)
                      'SC_type'      => 'VALUE'     # eg. 'folder'
                      'SC_indicator' => 'STRING'    # Anything identifing the folder
                    }
                }
            }
  
        2 = {
              'indent' =>                   
                {
                  'right' => 'Any text'        # Text only used for debugging
                }
            }
  
        3 = {
              'indent' =>                   
                {
                  'left' => 'Any text'       # Text only used for debugging
                }
            }

    Record format 1 is the data record.  As-of 3/18/2020 only the "series", "subseries", and "file" AO-level types
    were supported ( ie tested )

    Record format 2 causes all the records following the "indent => right" record to be attached to the record PRIOR to 
    the "indent => right" record.

    Record format 3 causes all the records following the "indent => left" record to be attached to the record PRIOR to
    the previous "indent => right" record. At the end of the program run, an "indent counter" is displayed, which should
    be 0 IF the number of right-dents equals the number left-dents.  Sometimes, there's no final indent-left tho.

=end

require 'json'
require 'pp'
require 'optparse'

require 'class.Array.extend.rb'
require 'class.String.extend.rb'
require 'class.Hash.extend.rb'
require 'module.Stderr.rb'
require 'class.Archivesspace.rb'
require 'class.ArchivesSpace.http_calls.rb'
require 'class.Archivesspace.ArchivalObject.rb'
require 'class.Archivesspace.Repository.rb'
require 'class.Archivesspace.TopContainer.rb'
require 'class.Archivesspace.Resource.rb'


BEGIN {}
END {}

myself_name = File.basename( $0 )
api_uri_base = "http://localhost:8089"

cmdln_option = { "as-repository-num" => 2  ,
                 "as-resource-num" => nil  ,
                 "as-ao-ref" => nil  ,
                 "update" => false ,
                 'last_record_num' => nil}
OptionParser.new do |option|
    option.banner = "Usage: #{myself_name} [ options ] FILE"
    option.on( "--as-repository-num n", OptionParser::DecimalInteger, "Repository number ( default = 2 )" ) do |opt_arg|
        cmdln_option[ 'as-repository-num' ] = opt_arg
    end
    option.on( "--as-resource-num n", OptionParser::DecimalInteger, "Resource number ( required )" ) do |opt_arg|
        cmdln_option[ 'as-resource-num' ] = opt_arg
    end
    option.on( "--as-ao-ref x", "Archival Object ReferenceID ( optional, but must be member of suppled Resource number )" ) do |opt_arg|
        cmdln_option[ 'as-ao-ref' ] = opt_arg
    end
    option.on( "--update", "Do updates" ) do |opt_arg|
        cmdln_option[ 'update' ] = true
    end
    option.on( "--last-record-num n", OptionParser::DecimalInteger, "Stop after record N" ) do |opt_arg|
        cmdln_option[ 'last-record-num' ] = opt_arg
    end
    option.on( "-h","--help" ) do
        Stderr.puts option
        exit
    end
end.parse!  # Bang because ARGV is altered
#p cmdln_option
#p ARGV
if ( cmdln_option[ 'as-repository-num' ] ) then
    repository_num = cmdln_option[ 'as-repository-num' ]
else
    Stderr.puts "The --as-repository-num option is required."
    raise
end
if ( cmdln_option[ 'as-resource-num' ] ) then
    resource_num = cmdln_option[ 'as-resource-num' ]
else
    Stderr.puts "The --as-resource-num option is required."
    raise
end
if ( cmdln_option[ 'as-ao-ref' ] ) then
    cmdln_AO_ref = cmdln_option[ 'as-ao-ref' ]      
else
    cmdln_AO_ref = nil
end
if ( cmdln_option[ 'last-record-num' ] ) then
    last_record_num = cmdln_option[ 'last-record-num' ]      
else
    last_record_num = nil
end
$global_update=cmdln_option[ 'update' ] 

aspace_O = ASpace.new
aspace_O.api_uri_base = api_uri_base
aspace_O.login( "admin", "admin" )
#Stderr.pom(aspace_O)
#Stderr.pov(aspace_O)
rep_O = ASpace::Repository.new( aspace_O, repository_num )
#Stderr.pom(rep_O)
#Stderr.pov(rep_O)

res_buf_O = ASpace::Resource_Record_Buf.new( rep_O, resource_num ).read
res_tree_query_O = ASpace::Tree_Query.new( rep_O ).get_resource_tree( resource_num )
res_tree_A_of_AO_record_buf_O = res_tree_query_O.get_res_tree_A_of_AO_record_buf_O( res_buf_O, res_tree_query_O.result[ K.children ], [ ] )
res_tree_A_of_AO_record_buf_O.each do | element |
    puts "#{element.record_H[ K.uri ]}, pos=#{element.record_H[ K.position ]}, #{element.record_H[ K.title ]}"
end



