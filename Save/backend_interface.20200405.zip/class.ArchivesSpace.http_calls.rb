=begin

Abbreviations,  AO = archival object(Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                AS = ArchivesSpace
                IT = instance type
                TC = top container
                SC = Sub-container
                _H = Hash
                _A = Array
                _I = Index(of Array)
                _O = Object
               _0R = Zero Relative

=end

class ASpace

    class Record_Buf < Buffer_Base
        def initialize( p1_aspace_O )
            super( )
            @cant_change_A << K.uri
            @http_calls_O = ASpace::Http_Calls.new( p1_aspace_O )
        end
        attr_reader :http_calls_O
        
        def read
            http_response_body_H = @http_calls_O.http_get( @uri )
            return http_response_body_H
        end
        
        def store
            if (@record_H == nil or ( @record_H.has_key?( K.uri) and @record_H[ K.uri ] != @uri )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Store failed"
                Stderr.puts "Current @record_H[ K.uri ] != @uri"
                Stderr.puts "@uri = #{@uri}"
                Stderr.pp "Current @record_H:", @record_H
                raise
            end
            if ( $global_update ) then
                http_response_body_H = @http_calls_O.http_post_with_body( @uri, @record_H )
                if ( http_response_body_H[K.status] != 'Created' ) then 
                    Stderr.puts "#{Stderr.lineno}: =============================================="
                    Stderr.puts "Create failed"
                    Stderr.puts "@uri = #{@uri}"
                    Stderr.puts "@record_H:", @record_H
                    Stderr.pp "http_response_body_H:", http_response_body_H
                    raise
                end
            else
                http_response_body_H = {K.uri => "NO UPDATE MODE"}
            end
            return http_response_body_H
        end

        def delete
            if (@record_H == nil or not ( @record_H.has_key?( K.uri) and @record_H[ K.uri ] == @uri )) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Delete failed"
                Stderr.puts "Current @record_H[ K.uri ] != @uri"
                Stderr.puts "@uri = #{@uri}"
                Stderr.pp "Current @record_H:", @record_H
                raise
            end
            if ( $global_update ) then
                http_response_body_H = @http_calls_O.http_delete( @uri, { } )
                if ( http_response_body_H[K.status] != 'Deleted' ) then 
                    Stderr.puts "#{Stderr.lineno}: =============================================="
                    Stderr.puts "Delete failed"
                    Stderr.puts "@uri = #{@uri}"
                    Stderr.pp "http_response_body_H:", http_response_body_H
                    raise
                end
            else
                http_response_body_H = {K.uri => "NO UPDATE MODE"}
            end
            return http_response_body_H
        end
    end

    class Http_Calls
    
        require "net/http"
        require 'uri'
        require "json"
    
        def initialize( p1_aspace_O )
            if ( p1_aspace_O.class != ASpace ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "Param 1 is not a ASpace class object"
                raise
            end    
            @aspace_O = p1_aspace_O
        end
        
        def http_get( p1_uri, p2_params = { } )
        #   Stderr.pov( uri ) 
                
            uri = URI.parse( "#{@aspace_O.api_uri_base}#{p1_uri}" )
            uri.query = URI.encode_www_form( p2_params )
            http = Net::HTTP.new(uri.host, uri.port)
        #   http.set_debug_output( $stderr )
        #   Stderr.pov( http )
                
            headers = { "Content-type" => "application/json", "X-ArchivesSpace-Session" => @aspace_O.session }
            response = http.request( Net::HTTP::Get.new( uri.request_uri, headers ))
        #   Stderr.pov( response )
        #   Stderr.pom( response )
        #   Stderr.pp response.to_H   # This defaults to printing the headers
        #   response.each_header do |key, value|
        #       Stderr.puts "#{key} => #{value}"
        #   end
            if ( response.code != "200" ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "p1_uri = #{p1_uri}"
                Stderr.puts "p2_params = #{p2_params}"
                Stderr.puts "response.code = #{response.code}"
                Stderr.puts "response.body:" , response.body
                raise
            end
            response_body = JSON.parse( response.body )
            return response_body
        end           
        
        def http_post_with_params( p1_uri, p2_params = { } )  
            uri = URI.parse("#{@aspace_O.api_uri_base}/#{p1_uri}")
            uri.query = URI.encode_www_form( p2_params )  # Params are after the ? in the URL
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )    
            if ( @aspace_O.session == nil ) then
                headers = { "Content-type" => "application/json" }
            else
                headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}
            end
            response_O = http.request( Net::HTTP::Post.new( uri.request_uri, headers ))    
            if ( response_O.code != "200" ) then 
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
            return response_body
        end

        def http_post_with_body( p1_uri, p2_input_H )     
            uri = URI.parse("#{@aspace_O.api_uri_base}#{p1_uri}")       
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )      
            headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}
            input_O = Net::HTTP::Post.new( uri.request_uri, headers )
            input_O.body = p2_input_H.to_json
            response_O = http.request( input_O )
            if ( response_O.code != "200" ) then
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.puts "p1_uri = #{p1_uri}"
                Stderr.puts "p2_input_H:", p2_input_H
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
        #   Stderr.pp "response_body", response_body
            return response_body;
        end 
        
        def http_delete( p1_uri, p2_params = { } )  
            uri = URI.parse("#{@aspace_O.api_uri_base}/#{p1_uri}")
            uri.query = URI.encode_www_form( p2_params )  # Params are after the ? in the URL
            http = Net::HTTP.new( uri.host, uri.port )
        #   http.set_debug_output( $stderr )    
            headers = { "Content-type" => "application/json" , 'X-ArchivesSpace-Session' => @aspace_O.session}  
            response_O = http.request( Net::HTTP::Delete.new( uri.request_uri, headers ))
            if ( response_O.code != "200" ) then 
                Stderr.puts "#{Stderr.lineno}: =============================================="
                Stderr.puts "response_O.code = #{response_O.code}"
                Stderr.pp "response_O.body:" , response_O.body
                raise
            end
            response_body = JSON.parse( response_O.body )
            return response_body
        end
    end
end



