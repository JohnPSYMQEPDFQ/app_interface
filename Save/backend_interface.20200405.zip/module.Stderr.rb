module Stderr
    def Stderr.puts(*params)
        params.each do |p|
            $stderr.puts p
        end
    end
    def Stderr.pp(*params)
        params.each do |p|
            $stderr.puts PP.pp(p, '')
        end
    end
    def Stderr.p(*params)
        params.each do |p|
            $stderr.puts p.inspect
        end
    end
    def Stderr.pov( p1_O )  # Print Object's Variables
        Stderr.puts "#{p1_O.class.name} Variables:"
        p1_O.instance_variables.map{|var| Stderr.puts [ var, p1_O.instance_variable_get( var ) ].join( "=" )}
    end
    def Stderr.pom( p1_O )  # Print Object's Methods
        Stderr.puts "#{p1_O.class.name} Methods:"
        Stderr.puts ( p1_O.methods - Object.methods ).map{|x| x = "#{p1_O.class.name} #{x}"}.sort
    end
    def Stderr.lineno()
        return caller[0].sub(/^.*\//,"").sub(/:in .* in /,":in ")
    end
end

