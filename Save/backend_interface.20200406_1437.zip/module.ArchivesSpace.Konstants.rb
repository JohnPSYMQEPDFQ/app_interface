module K
    def K.active_restrictions; return 'active_restrictions'.freeze; end   # top_container
    def K.ancestors; return 'ancestors'.freeze; end   # archival_object
    def K.ao_date_array; return '__AO_DATE_ARRAY__'.freeze; end   # formatter
    def K.ao_note_array; return '__AO_NOTE_ARRAY__'.freeze; end   # formatter
    def K.archival_object; return 'archival_object'.freeze; end   # root
    def K.archival_objects; return 'archival_objects'.freeze; end    # <<<< Danger Plural
    def K.barcode; return 'barcode'.freeze; end   # top_container
    def K.begin; return 'begin'.freeze; end   # dates
    def K.box; return 'box'.freeze; end   # top_container
    def K.calendar; return 'calendar'.freeze; end   # dates
    def K.certainty; return 'certainty'.freeze; end   # dates
    def K.children; return 'children'.freeze; end
    def K.classifications; return 'classifications'.freeze; end   # resource
    def K.collection; return 'collection'.freeze; end   # top_container
    def K.container_format_1; return 'CONTAINER_FORMAT_1'.freeze; end   # top_container
    def K.container_locations; return 'container_locations'.freeze; end   # top_container
    def K.content; return 'content'.freeze; end
    def K.create_time; return 'create_time'.freeze; end
    def K.created_by; return 'created_by'.freeze; end
    def K.created_for_collection; return 'created_for_collection'.freeze; end
    def K.date; return 'date'.freeze; end   # revision_statements
    def K.date_type; return 'date_type'.freeze; end   # dates
    def K.dates; return 'dates'.freeze; end   # archival_object, resource
    def K.deaccessions; return 'deaccessions'.freeze; end   # resource
    def K.description; return 'description'.freeze; end   # revision_statements
    def K.dimensions; return 'dimensions'.freeze; end   # extents
    def K.display_string; return 'display_string'.freeze; end
    def K.ead_location; return 'ead_location'.freeze; end   # resource
    def K.end; return 'end'.freeze; end   # dates
    def K.era; return 'era'.freeze; end   # dates
    def K.existence; return 'existence'.freeze; end   # dates
    def K.exported_to_ils; return 'exported_to_ils'.freeze; end   # top_container
    def K.expression; return 'expression'.freeze; end   # dates
    def K.extent_type; return 'extent_type'.freeze; end   # extents
    def K.extents; return 'extents'.freeze; end   # archival_object, resource
    def K.external_documents; return 'external_documents'.freeze; end   # archival_object, resource
    def K.external_ids; return 'external_ids'.freeze; end   # archival_object, resource
    def K.file; return 'file'.freeze; end
    def K.finding_aid_date; return 'finding_aid_date'.freeze; end   # resource
    def K.finding_aid_description_rules; return 'finding_aid_description_rules'.freeze; end   # resource
    def K.finding_aid_language; return 'finding_aid_language'.freeze; end   # resource
    def K.finding_aid_language_note; return 'finding_aid_language_note'.freeze; end   # resource
    def K.finding_aid_note; return 'finding_aid_note'.freeze; end   # resource
    def K.finding_aid_script; return 'finding_aid_script'.freeze; end   # resource
    def K.finding_aid_series_statement; return 'finding_aid_series_statement'.freeze; end   # resource
    def K.folder; return 'folder'.freeze; end
    def K.has_unpublished_ancestor; return 'has_unpublished_ancestor'.freeze; end
    def K.id_0; return 'id_0'.freeze; end   # resource
    def K.ils_holding_id; return 'ils_holding_id'.freeze; end   # top_container
    def K.ils_item_id; return 'ils_item_id'.freeze; end   # top_container
    def K.inclusive; return 'inclusive'.freeze; end
    def K.indent; return '__INDENT__'.freeze; end
    def K.indicator; return 'indicator'.freeze; end   # top_container
    def K.indicator_2; return 'indicator_2'.freeze; end   # sub_container
    def K.indicator_3; return 'indicator_3'.freeze; end   # sub_container
    def K.ingest_problem; return 'ingest_problem'.freeze; end
    def K.instance_type; return 'instance_type'.freeze; end   # instances
    def K.instances; return 'instances'.freeze; end   # archival_object, resource
    def K.is_representative; return 'is_representative'.freeze; end   # instances
    def K.is_slug_auto; return 'is_slug_auto'.freeze; end   # archival_object, resource
    def K.jsonmodel_type; return 'jsonmodel_type'.freeze; end   # archival_object, dates, extents, instances, lang_materials, langauge_and_script, resource, revision_statments, sub_container, top_container
    def K.label; return 'label'.freeze; end   # dates
    def K.lang_materials; return 'lang_materials'.freeze; end   # archival_object, resource
    def K.language; return 'language'.freeze; end   # language_and_script
    def K.language_and_script; return 'language_and_script'.freeze; end   # lang_materials
    def K.last_modified_by; return 'last_modified_by'.freeze; end
    def K.left; return 'left'.freeze; end
    def K.level; return 'level'.freeze; end   # archival_object, resource
    def K.linked_agents; return 'linked_agents'.freeze; end   # archival_object, resource
    def K.linked_events; return 'linked_events'.freeze; end   # archival_object, resourcr
    def K.lock_version; return 'lock_version'.freeze; end
    def K.mixed_materials; return 'mixed_materials'.freeze; end
    def K.node_type; return 'node_type'.freeze; end
    def K.note_multipart; return 'note_multipart'.freeze; end 
    def K.note_text; return 'note_text'.freeze; end
    def K.notes; return 'notes'.freeze; end   # archival_object, lang_materials, resource
    def K.number; return 'number'.freeze; end   # extents
    def K.parent; return 'parent'.freeze; end
    def K.password; return 'password'.freeze; end
    def K.persistent_id; return 'persistent_id'.freeze; end
    def K.physical_details; return 'physical_details'.freeze; end   # extents
    def K.portion; return 'portion'.freeze; end   # extents
    def K.position; return 'position'.freeze; end
    def K.processinfo; return 'processinfo'.freeze; end
    def K.publish; return 'publish'.freeze; end
    def K.record; return '__RECORD__'.freeze; end
    def K.record_indent_keys; return '__RECORD_INDENT_KEYS__'.freeze; end
    def K.record_num; return '__RECORD_NUM__'.freeze; end
    def K.record_original; return '__RECORD_ORIGINAL__'.freeze; end
    def K.record_uri; return 'record_uri'.freeze; end
    def K.record_values; return '__RECORD_VALUES__'.freeze; end
    def K.recordgrp; return 'recordgrp'.freeze; end  #archival_object
    def K.ref; return 'ref'.freeze; end   # archival_object, sub_container
    def K.ref_id; return 'ref_id'.freeze; end   # archival_object
    def K.related_accessions; return 'related_accessions'.freeze; end   # resource
    def K.repository; return 'repository'.freeze; end
    def K.resource; return 'resource'.freeze; end   # archival_object
    def K.resource_tree; return 'resource_tree'.freeze; end
    def K.restrictions; return 'restrictions'.freeze; end   # resource
    def K.restrictions_apply; return 'restrictions_apply'.freeze; end   # archival_object
    def K.revision_statements; return 'revision_statements'.freeze; end   # resource
    def K.right; return 'right'.freeze; end
    def K.rights_statements; return 'rights_statements'.freeze; end   # archival_object, resource
    def K.sc_indicator; return '__SC_INDICATOR__'.freeze; end   # sub_container
    def K.sc_type; return '__SC_TYPE__'.freeze; end   # sub_container
    def K.script; return 'script'.freeze; end   # language_and_script
    def K.series; return 'series'.freeze; end   # top_container
    def K.session; return 'session'.freeze; end
    def K.single; return 'single'.freeze; end
    def K.status; return 'status'.freeze; end   # http
    def K.sub_container; return 'sub_container'.freeze; end   # instances
    def K.subjects; return 'subjects'.freeze; end   # archival_object, resource
    def K.subnotes; return 'subnotes'.freeze; end
    def K.subseries; return 'subseries'.freeze; end
    def K.suppressed; return 'suppressed'.freeze; end
    def K.system_mtime; return 'system_mtime'.freeze; end
    def K.tc_indicator; return '__TC_INDICATOR__'.freeze; end   # sub_container
    def K.tc_type; return '__TC_TYPE__'.freeze; end   # sub_container
    def K.title; return 'title'.freeze; end   # archival_object, resource
    def K.top_container; return 'top_container'.freeze; end   # sub_container
    def K.type; return 'type'.freeze; end   # top_container
    def K.type_2; return 'type_2'.freeze; end   # sub_container
    def K.type_3; return 'type_3'.freeze; end   # sub_container
    def K.undefined; return '__UNDEFINED__'.freeze; end  # programs
    def K.unused; return '__UNUSED__'.freeze; end  # programs
    def K.uri; return 'uri'.freeze; end
    def K.user_mtime; return 'user_mtime'.freeze; end
end
include K
