=begin

Abbreviations,  AO = archival object (Everything's an AO, but there's also uri "archive_objects". It's confusing...)
                TC = top container
                IT = instance type
                AS = ArchivesSpace
                _H = Hash
                _A = Array
                _I = Index of Array
               _0R = Zero Relative

=end


class Record_Indent_Stack
require 'module.Stderr.rb'

    def self.new_with_flush(*args)
        stack = new(*args)
        yield stack
        stack.flush
    end

    def initialize(record_print_method, indent_print_method, stack_size_0R, indent_keys_prefixes_A = [  ] )
        @record_print_method = record_print_method
        @indent_print_method = indent_print_method
        if (stack_size_0R < 1) then
            Stderr.puts "#{Stderr.lineno}: initialize, param2, must be 1 or greater."
            raise
        end
        @record_stack_size_0R = stack_size_0R
        @record_stack_A = []
        if (! indent_keys_prefixes_A.empty?) then
            if (! indent_keys_prefixes_A[0].is_a?(Array)) then
                Stderr.puts "#{Stderr.lineno}: initialize, param3, must be an array of arrays" +
                            " (eg. [ [ '/', 0] ] -or- [ [ '/', 0 ], [ 'x', 3 ] ]"
                raise
            end
        end
        @indent_key_stack_A = indent_keys_prefixes_A
        if ( @indent_key_stack_A.empty? or @indent_key_stack_A[0] != '/' ) then
            @indent_key_stack_A.unshift( [ '/', 0 ])
        end
        @indent_key_prefixes_A = @indent_key_stack_A.transpose[0]
    end
    private_class_method :new

    def flush
        @record_stack_size_0R = 0
        loop do
            break if (@record_stack_A.maxindex < 0)
            self.add_record( {} )
        end
        Stderr.pp "#{Stderr.lineno}: @indent_key_stack_A:", @indent_key_stack_A if ( ! @indent_key_stack_A.empty? )
    end


    def add_record( p1_new_record_H )
        @record_stack_A.push( p1_new_record_H ) if (! p1_new_record_H.empty?)
        Stderr.pp "#{Stderr.lineno}: @record_stack_A:", @record_stack_A if ( $DEBUG )
        Stderr.pp "#{Stderr.lineno}: @record_stack_A.maxindex:", @record_stack_A.maxindex if ( $DEBUG )
        Stderr.pp "#{Stderr.lineno}: @indent_key_stack_A:", @indent_key_stack_A if ( $DEBUG )
        return {} if ( @record_stack_A.maxindex < @record_stack_size_0R ) 
    
        first_record_H = @record_stack_A.shift( 1 )[ 0 ]
        first_record_indent_keys_A = @indent_key_prefixes_A + first_record_H[ K.record_indent_keys ]
        highest_matched_indent_key_idx_A = [ ] 
        @record_stack_A.each_with_index do |other_record_H, record_stack_I|
            other_record_indent_keys_A = @indent_key_prefixes_A + other_record_H[ K.record_indent_keys ] 
            indent_key_I = 0; loop do
                Stderr.p "#{Stderr.lineno}: indent_key_I=#{indent_key_I}, " +
                         "first_record_indent_keys_A.maxindex=#{first_record_indent_keys_A.maxindex}, " +
                         "other_record_indent_keys_A.maxindex=#{other_record_indent_keys_A.maxindex}" if ( $DEBUG )
                break if ( indent_key_I > first_record_indent_keys_A.maxindex or indent_key_I > other_record_indent_keys_A.maxindex )
                Stderr.p "#{Stderr.lineno}: first_record_indent_keys_A[ #{indent_key_I} ]" +
                         "='#{first_record_indent_keys_A[ indent_key_I ]}', " +
                         "other_record_indent_keys_A[ #{indent_key_I} ]='#{other_record_indent_keys_A[ indent_key_I ]}'" if ( $DEBUG )
                break if ( first_record_indent_keys_A[ indent_key_I ].downcase != other_record_indent_keys_A[ indent_key_I ].downcase )
                indent_key_I += 1        
            end
            indent_key_I += -1        
            highest_matched_indent_key_idx_A[ record_stack_I ] = indent_key_I
            Stderr.p "#{Stderr.lineno}: highest_matched_indent_key_idx_A:", highest_matched_indent_key_idx_A if ( $DEBUG )
        end
        indent_key_I = @indent_key_stack_A.maxindex; loop do
            break if ( indent_key_I < 0 )
            Stderr.p "#{Stderr.lineno}: indent_key_I=#{indent_key_I}" if ( $DEBUG )
            Stderr.p "#{Stderr.lineno}: @indent_key_stack_A.maxindex=#{@indent_key_stack_A.maxindex}" if ( $DEBUG )
            Stderr.p "#{Stderr.lineno}: @indent_key_stack_A[ indent_key_I ][ 0 ]" +
                     "=#{@indent_key_stack_A[ indent_key_I ][ 0 ]}" if ( $DEBUG )
            Stderr.p "#{Stderr.lineno}: first_record_indent_keys_A.maxindex=#{first_record_indent_keys_A.maxindex}" if ( $DEBUG )
            if (   indent_key_I > first_record_indent_keys_A.maxindex\
                or @indent_key_stack_A[ indent_key_I ][ 0 ].downcase != first_record_indent_keys_A[ indent_key_I ].downcase ) then
                a1 = @indent_key_stack_A.pop( 1 )[ 0 ]
                output_record_H = {}
                output_record_H[ K.indent ] = {}
                output_record_H[ K.indent ] = [ K.left, a1[ 0 ] ]
                puts output_record_H.to_json 
            else
                Stderr.p "#{Stderr.lineno}: first_record_indent_keys_A[ indent_key_I ].downcase=" +
                         "#{first_record_indent_keys_A[ indent_key_I ].downcase}" if ( $DEBUG )
            end
            indent_key_I += -1
        end 
        if ( highest_matched_indent_key_idx_A.maxindex >= 0 ) then
            matched_indent_key_indexes_are_in_desc_order = ( highest_matched_indent_key_idx_A.each_cons( 2 ).all?{|left, right| left >= right} )
            Stderr.p "#{Stderr.lineno}: matched_indent_key_indexes_are_in_desc_order" + 
                     "=#{matched_indent_key_indexes_are_in_desc_order}" if ( $DEBUG )
            if ( matched_indent_key_indexes_are_in_desc_order ) then
                indent_key_I = -1; loop do 
                    indent_key_I += 1
                    Stderr.p "#{Stderr.lineno}: indent_key_I=#{indent_key_I} " +
                             "highest_matched_indent_key_idx_A.min=#{highest_matched_indent_key_idx_A.min} " +
                             "@indent_key_stack_A.maxindex=#{@indent_key_stack_A.maxindex} " +
                             "first_record_indent_keys_A.maxindex=#{first_record_indent_keys_A.maxindex} " if ( $DEBUG )
                    break if ( indent_key_I > highest_matched_indent_key_idx_A.min )
                    Stderr.p "#{Stderr.lineno}: indent_key_I=#{indent_key_I} " +
                             "@indent_key_stack_A.maxindex=#{@indent_key_stack_A.maxindex}" if ($DEBUG)
                    if  (  indent_key_I > @indent_key_stack_A.maxindex \
                        or @indent_key_stack_A[ indent_key_I ][ 0 ].downcase != first_record_indent_keys_A[ indent_key_I ].downcase ) then
                        if ( indent_key_I > @indent_key_stack_A.maxindex )
                        then
                            @indent_key_stack_A[ indent_key_I ] = [ "", 0 ]
                            @indent_key_stack_A[ indent_key_I ][ 0 ] = first_record_indent_keys_A[ indent_key_I ]
                            Stderr.p "#{Stderr.lineno}: @indent_key_stack_A[ #{indent_key_I} ]" +
                                     "=#{@indent_key_stack_A[ indent_key_I ]}" if ( $DEBUG )
                        end
                        if ( indent_key_I > 0 ) then
                            @indent_key_stack_A[ indent_key_I - 1 ][ 1 ] += 1
                            idx = -1; a1 = [ ]; loop do
                                idx += 1
                                break if ( idx >= indent_key_I )
                                a1.push( "#{@indent_key_stack_A[ idx ][ 1 ]}" )   # a1 is the series numbers n.n.n.etc...
                            end 
                            idx = 0; a2 = [ ]; loop do
                                idx += 1
                                break if ( idx > indent_key_I )
                                a2.push( "#{@indent_key_stack_A[ idx ][ 0 ]}" )   # a2 is the series title text.
                            end
                            @indent_print_method.call( a1, a2 )
                            output_record_H={}
                            output_record_H[ K.indent ] = [ K.right,  "GROUP #{a1.join( "." )}: #{a2.join( ". " )}" ]
                            puts output_record_H.to_json
                        end
                    end
                end 
            end
        end
        @record_print_method.call( first_record_H )
    end
end
